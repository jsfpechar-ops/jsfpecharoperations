# Stay fee remittance: where to put everything

You have 5 files. Nothing is pushed to GitHub yet; you do it in the steps below.

| File | What it is | Where it goes |
|---|---|---|
| `stay-fee-remittance-core.patch` | Ready-made code for step 1: DB columns, calculator, Invoice companion PDF, 40 tests, design kit, updated plan | Applied to your repo with one command (Part A) |
| `PLAN_STAY_FEE_REMITTANCE.md` | The plan Cursor follows (the patch also places it in the repo) | Comes into the repo via the patch |
| `sample-hlaseni-invoice-companion.pdf` | What the finished Hlášení looks like | Only for you to compare with; also inside the patch |
| `01_CURSOR_PROMPTS.md` | Copy-paste prompts, one per step | You paste them into Cursor (Part B) |
| `00_START_HERE.md` | This guide | — |

---

## Part A: Put step 1 into your repo (10 minutes, Terminal)

1. **Save the patch** `stay-fee-remittance-core.patch` to your Downloads folder.
2. **Open Terminal** and go to your local clone of `jsfpechar-ops/jsfpecharoperations`:
   `cd ~/path/to/jsfpecharoperations`
3. **Get current main.** The patch is built on commit `cf5dd4e`:
   ```
   git checkout main
   git pull
   git log --oneline -1
   ```
   A newer top commit is fine as long as step 4 doesn't error.
4. **Create the branch and apply the patch:**
   ```
   git checkout -b feat/stay-fee-core
   git apply --binary ~/Downloads/stay-fee-remittance-core.patch
   ```
   Whitespace warnings about the PDF files are harmless. Any other error: stop and send me the message.
5. **Check what landed.** `git status` should list about 13 files: `App/app/db.py`, `stay_fee.py`, `stay_fee_remittance_pdf.py`, `validation.py`, `App/tests/test_stay_fee.py`, three files in `docs/plans/stay-fee-remittance-design/`, and the plan and mockups in `docs/plans/stay-fee-remittance/`.
6. **Run the tests** (Python 3.12 virtualenv, as for your other work):
   ```
   cd App
   .venv/bin/python -m pytest tests/test_stay_fee.py tests/test_db_upgrade.py tests/test_payments.py tests/test_host_i18n.py -q
   ```
   Expect all green (60 passed). Then run the whole suite once and note any failures, and compare with `main` to see which were already failing.
7. **Look at the sample:**
   `.venv/bin/python ../docs/plans/stay-fee-remittance-design/build_sample.py`
   Open the PDF it writes and compare with `sample-hlaseni-invoice-companion.pdf`. They should look the same.
8. **Commit, push, open the PR:**
   ```
   cd ..
   git add -A
   git commit -m "feat: stay-fee remittance core (calculator, Invoice companion PDF, tests, plan v2)"
   git push -u origin feat/stay-fee-core
   ```
   On GitHub open a pull request into `main`, wait for CI to go green, then merge. Never push to `main` directly.

**Important:** step 1 changes the database (new columns plus a one-time reset of leftovers from the reverted 26 Sep build). It changes no screen. Nothing is visible to hosts or guests yet, and rate 0 = off everywhere.

---

## Part B: Steps 2–8 with Cursor (one PR each)

1. After step 1 is merged, open the repo in Cursor: `git checkout main && git pull`.
2. Open `01_CURSOR_PROMPTS.md`. Paste **Prompt 0** (the master rules) into a new Cursor chat. It tells Cursor to read the plan first.
3. For each step in order, start a **new chat**, paste Prompt 0, then the matching step prompt, and let Cursor work.
4. When Cursor finishes a step, check:
   - the tests it names pass (`pytest` in `App`)
   - the whole suite has no new failures against your baseline
   - `git diff` touches only the files that step needs
5. Push the branch, open a PR, merge when CI is green, then `git checkout main && git pull` before the next step.

Order: 2 property panel, 3 document type, 4 signature, 5 list, 6 detail, 7 downloads, 8 docs.

---

## Part C: Staging test (Step 9, you)

After step 8 is merged, deploy **staging** as you normally do and go through the QA list at the end of plan §13 (a–g). The key checks:

- Set up your Praha 3 property (rate 50, VS, council account) in the property settings panel, and check that the QR scans in your bank app with the right amount and VS.
- Download the Hlášení and compare it with the sample.
- Exempt one guest, then check that the totals change in the list, detail, PDF and CSV.

Deploy to production only after that passes.

---

## Still open for you (plan §15)

Seven items for a lawyer or the council to confirm. None blocks building, but read them before real use. Until then keep rate 0 on properties you don't want live.

## Ignore

The older folder `stay_fee_remittance/` (no `_v2`) is obsolete.
